﻿using System;
using System.Text;

namespace MatematikaLibrary
{
    public static class Matematika
    {
        // A. FPB (Faktor Persekutuan Terbesar)
        public static int FPB(int a, int b)
        {
            while (b != 0)
            {
                int temp = b;
                b = a % b;
                a = temp;
            }
            return Math.Abs(a);
        }

        // B. KPK (Kelipatan Persekutuan Terkecil)
        public static int KPK(int a, int b)
        {
            return Math.Abs(a * b) / FPB(a, b);
        }

        // C. Turunan polinomial
        public static string Turunan(int[] koef)
        {
            StringBuilder hasil = new StringBuilder();
            int derajat = koef.Length - 1;

            for (int i = 0; i < koef.Length - 1; i++)
            {
                int pangkat = derajat - i;
                int turunan = koef[i] * pangkat;

                if (turunan == 0) continue;

                if (hasil.Length > 0)
                    hasil.Append(turunan > 0 ? " + " : " - ");
                else if (turunan < 0)
                    hasil.Append("-");

                hasil.Append(Math.Abs(turunan));

                if (pangkat - 1 > 0)
                    hasil.Append($"x{(pangkat - 1 > 1 ? $"^{pangkat - 1}" : "")}");
            }

            return hasil.ToString();
        }

        // D. Integral polinomial
        public static string Integral(int[] koef)
        {
            StringBuilder hasil = new StringBuilder();
            int derajat = koef.Length - 1;

            for (int i = 0; i < koef.Length; i++)
            {
                int pangkat = derajat - i + 1;
                double nilai = (double)koef[i] / pangkat;

                if (nilai == 0) continue;

                if (hasil.Length > 0)
                    hasil.Append(nilai > 0 ? " + " : " - ");
                else if (nilai < 0)
                    hasil.Append("-");

                if (Math.Abs(nilai) != 1)
                    hasil.Append($"{Math.Abs(nilai):G}");

                hasil.Append($"x{(pangkat > 1 ? $"^{pangkat}" : "")}");
            }

            hasil.Append(" + C");
            return hasil.ToString();
        }
    }
}
