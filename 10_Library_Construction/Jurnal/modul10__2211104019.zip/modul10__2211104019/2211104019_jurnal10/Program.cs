﻿using System;
using MatematikaLibrary;

namespace MatematikaApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("=== Pengujian Library Matematika ===");

            // A. FPB
            int a = 60, b = 45;
            Console.WriteLine($"FPB({a}, {b}) = {Matematika.FPB(a, b)}");

            // B. KPK
            int x = 12, y = 8;
            Console.WriteLine($"KPK({x}, {y}) = {Matematika.KPK(x, y)}");

            // C. Turunan
            int[] persamaanTurunan = { 1, 4, -12, 9 }; // x^3 + 4x^2 -12x + 9
            Console.WriteLine($"Turunan(x^3 + 4x^2 -12x + 9) = {Matematika.Turunan(persamaanTurunan)}");

            // D. Integral
            int[] persamaanIntegral = { 4, 6, -12, 9 }; // 4x^3 + 6x^2 -12x + 9
            Console.WriteLine($"Integral(4x^3 + 6x^2 -12x + 9) = {Matematika.Integral(persamaanIntegral)}");

            Console.WriteLine("=== Selesai ===");
        }
    }
}
