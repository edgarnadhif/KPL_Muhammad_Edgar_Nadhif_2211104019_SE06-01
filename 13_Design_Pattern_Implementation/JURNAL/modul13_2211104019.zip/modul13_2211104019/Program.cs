﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace modul13_2211104019
{
    class Program
    {
        static void Main(string[] args)
        {
            // Implementasi program utama
            PusatDataSingleton data1 = PusatDataSingleton.GetDataSingleton();
            PusatDataSingleton data2 = PusatDataSingleton.GetDataSingleton();

            Console.WriteLine("Menambahkan data ke data1...");
            data1.AddSebuahData("Anggota 1: John Doe");
            data1.AddSebuahData("Anggota 2: Jane Smith");
            data1.AddSebuahData("Asisten Praktikum: Alice Johnson");
            data1.AddSebuahData("Anggota 3: Bob Williams");

            Console.WriteLine("\nMencetak data dari data2:");
            data2.PrintSemuaData();

            Console.WriteLine("\nMenghapus asisten praktikum dari data2...");
            data2.HapusSebuahData(2);

            Console.WriteLine("\nMencetak data dari data1 setelah penghapusan:");
            data1.PrintSemuaData();

            Console.WriteLine("\nJumlah elemen data1: " + data1.GetSemuaData().Count);
            Console.WriteLine("Jumlah elemen data2: " + data2.GetSemuaData().Count);

            Console.WriteLine("\nMembuktikan bahwa data1 dan data2 adalah instance yang sama:");
            Console.WriteLine($"data1 == data2: {data1 == data2}");
            Console.WriteLine($"HashCode data1: {data1.GetHashCode()}");
            Console.WriteLine($"HashCode data2: {data2.GetHashCode()}");

            Console.WriteLine("\nTekan enter untuk keluar...");
            Console.ReadLine();
        }
    }
}

