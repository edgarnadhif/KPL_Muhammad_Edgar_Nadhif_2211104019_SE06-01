﻿using ProjectKamu;
using System;

class Program
{
    static void Main(string[] args)
    {

        long angka1 = 22;
        long angka2 = 11;
        long angka3 = 10;

        var hasil = Penjumlahan.JumlahTigaAngka<long>(angka1, angka2, angka3);
        Console.WriteLine($"Hasil penjumlahan: {hasil}");

        var database = new SimpleDataBase<long>();
        database.AddNewData(angka1);
        database.AddNewData(angka2);
        database.AddNewData(angka3);

        database.PrintAllData();
    }
}