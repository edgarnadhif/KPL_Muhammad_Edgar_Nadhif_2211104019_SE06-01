﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace tpmodul5_2211104019
{
    class Program
    {
        static void Main(string[] args)
        {

            HaloGeneric haloGeneric = new HaloGeneric();

            string namaPanggilan = "Praktikan";
            haloGeneric.SapaUser(namaPanggilan);
        }
    }
}
