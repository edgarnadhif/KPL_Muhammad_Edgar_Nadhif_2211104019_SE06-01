﻿using System;
using System.IO;
using System.Xml;
using Newtonsoft.Json;

/// <summary>
/// Class untuk mengelola konfigurasi COVID-19 (satuan suhu, batas hari demam, pesan respons).
/// </summary>
public class CovidConfig
{
    private const string FilePath = "covid_config.json";

    public string SatuanSuhu { get; set; }
    public int BatasHariDemam { get; set; }
    public string PesanDitolak { get; set; }
    public string PesanDiterima { get; set; }

    /// <summary>
    /// Constructor default dengan nilai konfigurasi awal.
    /// </summary>
    public CovidConfig()
    {
        SatuanSuhu = "celcius";
        BatasHariDemam = 14;
        PesanDitolak = "Anda tidak diperbolehkan masuk ke dalam gedung ini";
        PesanDiterima = "Anda dipersilahkan untuk masuk ke dalam gedung ini";
    }

    /// <summary>
    /// Memuat konfigurasi dari file JSON. Jika file tidak ada, buat file baru dengan nilai default.
    /// </summary>
    public void LoadConfig()
    {
        try
        {
            if (File.Exists(FilePath))
            {
                string jsonData = File.ReadAllText(FilePath);
                var config = JsonConvert.DeserializeObject<CovidConfig>(jsonData);

                SatuanSuhu = config.SatuanSuhu;
                BatasHariDemam = config.BatasHariDemam;
                PesanDitolak = config.PesanDitolak;
                PesanDiterima = config.PesanDiterima;
            }
            else
            {
                SaveConfig();
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error loading config: {ex.Message}");
        }
    }

    /// <summary>
    /// Menyimpan konfigurasi saat ini ke file JSON.
    /// </summary>
    public void SaveConfig()
    {
        try
        {
            string jsonData = JsonConvert.SerializeObject(this, Newtonsoft.Json.Formatting.Indented);
            File.WriteAllText(FilePath, jsonData);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error saving config: {ex.Message}");
        }
    }

    /// <summary>
    /// Mengubah satuan suhu antara Celcius dan Fahrenheit.
    /// </summary>
    public void UbahSatuan()
    {
        SatuanSuhu = (SatuanSuhu == "celcius") ? "fahrenheit" : "celcius";
        SaveConfig();
    }
}