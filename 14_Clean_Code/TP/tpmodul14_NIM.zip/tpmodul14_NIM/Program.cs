﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace tpmodul14_NIM
{
    using System;

    class Program
    {
        static void Main()
        {
            CovidConfig config = new CovidConfig();
            config.LoadConfig();

            try
            {
                Console.Write($"Berapa suhu badan Anda saat ini? Dalam nilai {config.SatuanSuhu}: ");
                double suhuBadan = Convert.ToDouble(Console.ReadLine());

                Console.Write("Berapa hari yang lalu (perkiraan) Anda terakhir memiliki gejala demam? ");
                int hariTerakhirDemam = Convert.ToInt32(Console.ReadLine());

                bool isSuhuNormal = CheckSuhuNormal(suhuBadan, config.SatuanSuhu);
                bool isHariDemamNormal = hariTerakhirDemam < config.BatasHariDemam;

                Console.WriteLine(isSuhuNormal && isHariDemamNormal ? config.PesanDiterima : config.PesanDitolak);

                Console.Write("Apakah ingin mengubah satuan suhu? (y/n): ");
                string inputUbah = Console.ReadLine().ToLower();

                if (inputUbah == "y")
                {
                    config.UbahSatuan();
                    Console.WriteLine($"Satuan suhu sekarang: {config.SatuanSuhu}");
                }
            }
            catch (FormatException)
            {
                Console.WriteLine("Input tidak valid. Harap masukkan angka.");
            }
        }

        private static bool CheckSuhuNormal(double suhu, string satuanSuhu)
        {
            return (satuanSuhu == "celcius" && suhu >= 36.5 && suhu <= 37.5) ||
                   (satuanSuhu == "fahrenheit" && suhu >= 97.7 && suhu <= 99.5);
        }
    }
}
