﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using modul12_2211104019; 

namespace tpmodul12_2211104019_Test
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void CariTandaBilangan_Negatif_ReturnNegatif()
        {
            // Arrange
            var helper = new MathHelper();
            int input = -5;
            string expected = "Negatif";

            // Act
            string actual = helper.CariTandaBilangan(input);

            // Assert
            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void CariTandaBilangan_Positif_ReturnPositif()
        {
            // Arrange
            var helper = new MathHelper();
            int input = 10;
            string expected = "Positif";

            // Act
            string actual = helper.CariTandaBilangan(input);

            // Assert
            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void CariTandaBilangan_Nol_ReturnNol()
        {
            // Arrange
            var helper = new MathHelper();
            int input = 0;
            string expected = "Nol";

            // Act
            string actual = helper.CariTandaBilangan(input);

            // Assert
            Assert.AreEqual(expected, actual);
        }
    }
}
