﻿using System;
using System.Windows.Forms;

namespace modul12_2211104019
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private int CariNilaiPangkat(int a, int b)
        {
            if (b == 0) return 1;
            if (b < 0) return -1;
            if (b > 10 || a > 100) return -2;

            try
            {
                checked
                {
                    int hasil = 1;
                    for (int i = 0; i < b; i++)
                    {
                        hasil *= a;
                    }
                    return hasil;
                }
            }
            catch (OverflowException)
            {
                return -3;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            labelHasil.Text = ""; // reset hasil dulu
            int a, b;

            if (int.TryParse(textBoxA.Text, out a) && int.TryParse(textBoxB.Text, out b))
            {
                int hasil = CariNilaiPangkat(a, b);
                switch (hasil)
                {
                    case -1:
                        labelHasil.Text = "Pangkat negatif tidak diperbolehkan.";
                        break;
                    case -2:
                        labelHasil.Text = "Input a > 100 atau b > 10 tidak diperbolehkan.";
                        break;
                    case -3:
                        labelHasil.Text = "Terjadi overflow! Hasil terlalu besar.";
                        break;
                    default:
                        labelHasil.Text = $"Hasil: {hasil}";
                        break;
                }
            }
            else
            {
                labelHasil.Text = "Masukkan angka valid!";
            }
        }
    }
}
