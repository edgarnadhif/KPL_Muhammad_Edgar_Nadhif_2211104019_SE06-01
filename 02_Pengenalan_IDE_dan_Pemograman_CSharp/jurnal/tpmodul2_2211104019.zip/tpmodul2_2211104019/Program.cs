﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace tpmodul2_2211104019
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Masukan Satu huruf:");
            char input = Char.ToUpper(Console.ReadKey().KeyChar);
            Console.WriteLine();

            if (input == 'A' || input == 'I' || input == 'U' || input == 'E' || input == 'O')
            {
                Console.WriteLine("Huruf {0} merupakan huruf vokal.", input);
            }
            else
            {
                Console.WriteLine("Huruf {0} merupakan huruf konsonan.", input);
            }

            Console.WriteLine(" ");

            // Membuat array bilangan genap dari angka 2
            int[] bilanganGenap = { 2, 4, 6, 8, 10 };

            for (int i = 0; i < bilanganGenap.Length; i++)
            {
                Console.WriteLine($"Angka genap {i + 1} : {bilanganGenap[i]}");
            }

        }
    }
}
