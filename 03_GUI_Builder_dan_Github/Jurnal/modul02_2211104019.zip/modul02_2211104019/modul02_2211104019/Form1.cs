﻿using System;
using System.Windows.Forms;

namespace modul02_2211104019
{
    public partial class Form1 : Form
    {
        private string input = "";
        private int num1 = 0;
        private int num2 = 0;
        private bool isSecondNumber = false;
        private string currentOperator = "";

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e) { AppendNumber("1"); }
        private void button2_Click(object sender, EventArgs e) { AppendNumber("2"); }
        private void button3_Click(object sender, EventArgs e) { AppendNumber("3"); }
        private void button4_Click(object sender, EventArgs e) { AppendNumber("4"); }
        private void button5_Click(object sender, EventArgs e) { AppendNumber("5"); }
        private void button6_Click(object sender, EventArgs e) { AppendNumber("6"); }
        private void button7_Click(object sender, EventArgs e) { AppendNumber("7"); }
        private void button8_Click(object sender, EventArgs e) { AppendNumber("8"); }
        private void button9_Click(object sender, EventArgs e) { AppendNumber("9"); }
        private void button0_Click(object sender, EventArgs e) { AppendNumber("0"); }

        private void buttonplus_Click(object sender, EventArgs e)
        {
            if (!isSecondNumber && input != "")
            {
                num1 = int.Parse(input);  
                currentOperator = "+";  
                input += " + "; 
                textBox1.Text = input;
                isSecondNumber = true;  
                input = "";  
            }
        }

        private void buttonequal_Click(object sender, EventArgs e)
        {
            if (isSecondNumber && input != "")
            {
                num2 = int.Parse(input); 
                int result = 0;

                if (currentOperator == "+")
                {
                    result = num1 + num2;
                }

                textBox1.Text = result.ToString(); 
                input = result.ToString();
                isSecondNumber = false;
            }
        }

        private void AppendNumber(string number)
        {
            input += number;
            textBox1.Text = textBox1.Text + number;
        }

        private void Textbox1(object sender, EventArgs e) { }
        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e) { }
    }
}
